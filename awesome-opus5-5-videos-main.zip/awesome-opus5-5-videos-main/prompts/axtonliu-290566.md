# Opus 5.5 video by @AxtonLiu

[▶ Watch the original and a live remake on Skillry](https://skillry.dev/ai-videos/opus-5-5/axtonliu-290566?utm_source=github&utm_medium=readme&utm_campaign=awesome-opus5-5-videos) · [Original post](https://x.com/AxtonLiu/status/2103119648271290566)

- **Category:** 3D scenes
- **Remake built with:** GLSL · WebGL
- **Author:** [@AxtonLiu](https://x.com/AxtonLiu)

## Prompt

```text
每次一个新的模型出来呢，大家都让它去画 “鹈鹕骑自行车” 来判断这个模型的空间能力，基本上都是用 HTML、SVG 来画动画。当我实在看得都有审美疲劳了，我希望你能画一个最复杂、最精细、最精美的 “鹈鹕骑自行车”的动画视频，你可以用任何的技术，不用着急，画一天都可以。
```
