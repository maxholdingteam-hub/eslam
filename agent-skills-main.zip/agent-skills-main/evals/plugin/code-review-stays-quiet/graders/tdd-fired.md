---
type: tool_used
tool: Skill
input_match: '"skill"\s*:\s*"(?:[\w-]+:)?(test-driven-development|test)"'
arm: with-only
---
